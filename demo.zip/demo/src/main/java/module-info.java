module edu.uam.ni.demo {
    requires javafx.controls;
    requires javafx.fxml;


    opens edu.uam.ni.demo to javafx.fxml;
    exports edu.uam.ni.demo;
}