package edu.uam.ni.demo;

public class RegistroCalificacionesController {
}
